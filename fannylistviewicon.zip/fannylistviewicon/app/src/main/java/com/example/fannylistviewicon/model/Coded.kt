package com.example.fannylistviewicon.model

class Coded {
    var name: String = ""
    var detail: String = ""
    var logo: Int = 0
}